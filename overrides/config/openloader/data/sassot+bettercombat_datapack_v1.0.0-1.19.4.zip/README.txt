Minecraft version: 1.19.4

Thank you for installing SASSOT compatible with Better Combat.

Please remember to install this data pack into your worlds for the full SASSOT + Better Combat experience. Have fun!