In order to use the datapack you need to enable both the Datapack and Resource pack.

1. You can enable the datapack by dragging the voa_data file into the Data Pack folder upon World Creation (Create New World >> More >> Data Packs)
Please make sure the voa_data pack is in the Selected column.

2. You can enable the Resource Pack by dragging the voa_resource file into the Resource Pack folder located in the main menu >> Options >> Resource Packs Tab.
Please make sure the Resource pack is Selected column.

-----------------------------------------------------------------------------------------------------------------
Realms -

In order to use this datapack on a Minecraft Realm, create the world in Single Player following step number 1 above.
Then upload the world to your realm.

Players of your realm only need to follow step number 2 located above. 
In other words, they only need to have the Resource Pack Enabled and Selected.

-----------------------------------------------------------------------------------------------------------------

Testing Data Pack - 

You can ensure this data pack was installed correctly by running the /reload command using chat bar.
If done correctly you should receive a: --- Vaults of Abandon Datapack Loaded --- Message.